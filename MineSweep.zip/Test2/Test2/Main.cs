using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Text;
using System.IO;
using System.Linq;

namespace Test2
{
	class MainClass
	{
		/// <summary>
		/// This the Mine Sweep Ganme
		/// </summary>
		#region Members
		private static int xArrayLength = 0;
		private static int yArrayLength = 0;
		private static int[,] board;
		private static int bombFlag = 1;
		#endregion
		
		#region Main
		public static void Main (string[] args)
		{
			///This is the Mine Sweeper
			
			Console.WriteLine ("Enter Board Area and number of bombs IE [XLength][Ylength][Number of Bombs]");
			string inputs = Console.ReadLine().ToString();
			string[] gameInfo = inputs.Split(' ');
			//char[] gameInfo = inputs.ToCharArray(" ");
			xArrayLength = int.Parse(gameInfo[0]);
			yArrayLength = int.Parse(gameInfo[1]);
			int bombs = int.Parse(gameInfo[2]);
			
			//First Create Board  
			board = new int[xArrayLength, yArrayLength];
			
			
			//set bombs
			Console.WriteLine ("Set Bomb Locations");
			for(int i = 0; i < bombs; i++)
			{
				//resue out tmp inputVaribles
				inputs = Console.ReadLine().ToString();
				gameInfo = inputs.Split(' ');
				board[int.Parse(gameInfo[0]), int.Parse(gameInfo[1])] = bombFlag;
				
			}
			StringBuilder sb = new StringBuilder();
			sb.AppendLine("The results are");
			sb.AppendLine(" ");	
			
			//XLoop
			for(int i =0; i< board.GetLength(0); i++)
			{
				//YLoop
				for(int j =0; j < board.GetLength(1); j++)
				{
					
					
					
					int mineCount = 0;
					if(board[i, j] != bombFlag)
					{
						
						mineCount = getMineCount(i, j);
						if(mineCount > 0)
						{
							sb.AppendFormat("{0} {1} {2}",i, j, mineCount);
							sb.AppendLine(" ");
						}
						
					}
					
				}//End of Inner Forloop
				
			}//End of Outer ForLoop
			//Console.Clear();
			Console.WriteLine(sb.ToString());
			
		}//end of Main
		#endregion
		
		#region Methods		
		private static int getMineCount(int x, int y)
		{
			int bombCount = 0;
			int xTmpPostion = 0;
			int yTmpPostion = 0;
			int tmpCheck = 0;
			
			//Check cell right below
			xTmpPostion = x;
			yTmpPostion = y - 1;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			//Check Cell below and to the Left
			//Reset our tmp Varibles
			yTmpPostion = 0;
			tmpCheck = 0;
			xTmpPostion = x -1;
			yTmpPostion = y -1;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			//Check to the Left
			//Reset our tmp Varibles
			yTmpPostion = 0;
			tmpCheck = 0;
			xTmpPostion = x -1;
			yTmpPostion = y;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			//Check to the Left and up one cell
			//Reset our tmp Varibles
			yTmpPostion = 0;
			tmpCheck = 0;
			xTmpPostion = x -1;
			yTmpPostion = y + 1;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			//Check  the cell above
			//Reset our tmp Varibles
			yTmpPostion = 0;
			tmpCheck = 0;
			xTmpPostion = x;
			yTmpPostion = y + 1;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			//Check  the cell above and to the right
 			//Reset our tmp Varibles
			yTmpPostion = 0;
			tmpCheck = 0;
			xTmpPostion = x + 1;
			yTmpPostion = y + 1;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			//Check  the cell to the right
 			//Reset our tmp Varibles
			yTmpPostion = 0;
			tmpCheck = 0;
			xTmpPostion = x + 1;
			yTmpPostion = y;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			//Check  the cell to the right and below
 			//Reset our tmp Varibles
			yTmpPostion = 0;
			tmpCheck = 0;
			xTmpPostion = x + 1;
			yTmpPostion = y - 1;
			if (isBoardSpace(xTmpPostion, yTmpPostion))
			{
				tmpCheck = board[xTmpPostion, yTmpPostion];
				if (tmpCheck > 0)
				{
					bombCount += 1;
				}
			}
			
			
			return bombCount;
		}// End of Main Check
	
		private static bool isBoardSpace(int x, int y)
		{
			if((x > -1 && x < xArrayLength) && (y > -1 && y < yArrayLength))
			{
				return true;
			}
			else
			{
				return false;
			}
			
		}
		
		#endregion
	
	}
	
	
	
}
