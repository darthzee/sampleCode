using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Text;
using System.IO;
using System.Linq;


namespace Test
{
	class MainClass
	{
		
		/// <summary>
		/// This 21 game
		/// </summary>
		
		#region Members
		private static int numOfhands = 0;
		public static readonly string[] LEGAL_CARDS = { "2", "3", "4", "5" ,"6" ,"7","8","9","J","K","A","Q"};
		#endregion
		
		#region Main Class
		public static void Main (string[] args)
		{
			Console.WriteLine ("Enter the Number of Hands you Which to Check");
			
			bool isNumber = checkNumber(Console.ReadLine().ToString());
			if (!isNumber)
			{
				Console.WriteLine("Please enter an valid number");
				//test = Console.ReadLine().ToString();
				
			}
			
			else
			{
				int handCount = 0;
				int currentHandTotal = 0;
				bool isValidHand = true;
				string tempHand = string.Empty;
				StringBuilder sb = new StringBuilder();
				while(handCount < numOfhands)
				{
					tempHand = string.Empty;
					isValidHand = true;
			
					
					tempHand = Console.ReadLine().ToString();
					isValidHand = CheckHand(tempHand);
					if (isValidHand)
					{
					 	currentHandTotal = bestHand(tempHand);
						sb.AppendFormat("The Best Hand for Hand {1} is {0}",currentHandTotal, handCount);
						sb.AppendLine("");
					}
					else
					{
						sb.AppendFormat("Hand {0} is not Valid", handCount);
						sb.AppendLine(" ");
					}
					handCount++;
				}	
				sb.AppendLine(" ");
				sb.AppendLine("Thank you for playing");
				Console.WriteLine(sb.ToString());
				
			}
			
			
			
		}// End of Main
		#endregion
		
		#region Methods
		
		private static bool CheckHand(string inputHand)
		{
			int pos = 0;
			char[] cards = inputHand.ToCharArray();
			foreach(char c in cards)
			{
				pos = Array.IndexOf(LEGAL_CARDS, c.ToString().ToUpper());
				if(pos < 0)
				{
					return false;
				}
			}
			return true;
		}
		
		
		/// <summary>
		/// This function will check for the best hand and return the number
		/// </summary>
		/// <returns>
		/// The hand.
		/// </returns>
		private static int bestHand(string hand)
		{
			int handTotal = 0;
			hand = hand.ToUpper();
			bool hasAce = false;
			bool hasFace = false;
			if (hand.Contains("A"))
			{
				hasAce = true;
			}
			if (hand.Contains("Q") || hand.Contains("J") || hand.Contains("K"))
			{
				hasFace = true;
			}
			
			if(hasAce && hasFace)
			{
				return 21;
			}
			char[] cards = hand.ToCharArray();
			string temp = string.Empty;
			List<int> cTotal = new List<int>();
			foreach (char c in cards)
			{
				temp = c.ToString();
				temp = temp.ToUpper();
				if(temp == "K" || temp == "Q" || temp == "J")
				{
					cTotal.Add(10);
				}
				else if(temp == "A")
				{
					cTotal.Add(11);

				}
				else 
				{
					cTotal.Add(int.Parse(temp));
				}
				
			}
			
			int[] totalArray = cTotal.ToArray();
			
			handTotal = totalArray.Sum();
			
			
			if(handTotal <= 21)
			{
				return handTotal;
			}
			
			handTotal = getHandTotal(totalArray);
			return handTotal;
			
		}
		
		
		/// <summary>
		/// This is the function that will the char array to get the best hand. 
		/// The card total was above 21
		/// </summary>
		/// <returns>
		/// The hand total.
		/// </returns>
		/// <param name='cards'>
		/// Cards.
		/// </param>
		private static int getHandTotal(int[] hand)
		{
			int arrayTotal = hand.Sum();
			int temphandTotal = 0;
			int bestHandtotal = 0;
			for (int i = 0; i < hand.Length; i++)
			{
				temphandTotal = arrayTotal - hand[i];
				if (temphandTotal > bestHandtotal && temphandTotal <= 21)
				{
					bestHandtotal = temphandTotal;
				}
					
			}
			
			if(hand.Length > 3 && bestHandtotal < 21)
			{
				
				for(int j = 0; j<hand.Length; j++)
				{
				int[] newArray = new int[hand.Length - 1];
				
				for (int k = 0; k < hand.Length; k++)
				{
				    if (k < j)
						{
				    		newArray[k] = hand[k];
						}
					if (k > j)
						{
				    		newArray[k-1] = hand[k];
						}
				}
				
					int total = getHandTotal(newArray);
					if (total > bestHandtotal && total < 22)
					{
						bestHandtotal = total;
					}
					
				}
				
			}
		
			
			return bestHandtotal;
			
			
		}
		
		
		/// <summary>
		/// Checks to make sure that we have a valid number of hands to check.
		/// </summary>
		/// <returns>
		/// The number.
		/// </returns>
		/// <param name='checkNumber'>
		/// If set to <c>true</c> check number.
		/// </param>
		private static bool checkNumber(string checkNumber)
		{
			
			bool isNumber = int.TryParse(checkNumber, out numOfhands);
			if (!isNumber)
			{
				return false;
			}
			
			return true;
			
			
		}
		#endregion
		
	}
}