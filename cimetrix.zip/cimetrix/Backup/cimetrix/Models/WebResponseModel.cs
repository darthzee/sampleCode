﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace cimetrix.Models
{
    public class WebResponseModel
    {
        public int returnCode { get; set; }
        public string returnMessage { get; set; }
        public List<ReturnData> data { get; set; } 
    }
}