﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace cimetrix.Models
{
    public class UserPostData
    {
        public Guid key { get; set; }
        public String downloadUrl { get; set; }
        public String title { get; set; }
        public String user { get; set; }
        public String ip { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
    }
}