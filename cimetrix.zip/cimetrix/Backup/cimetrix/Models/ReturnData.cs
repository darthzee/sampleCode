﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace cimetrix.Models
{
    public class ReturnData
    {
        public String downloadUrl { get; set; }
        public String title { get; set; }
        public String date { get; set; }
        public String ip { get; set; }
        public String user { get; set; }
    }
}