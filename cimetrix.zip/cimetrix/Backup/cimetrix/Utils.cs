﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using cimetrix.Models;
using cimetrix.Controllers;

namespace cimetrix
{
    public class Utils
    {
        #region formatResponse
        public static WebResponseModel formatResponse(int code, string message, List<ReturnData> data = null)
        {
            WebResponseModel webResponse = new WebResponseModel();
            webResponse.returnCode = code;
            webResponse.returnMessage = message;
            webResponse.data = data;
            return webResponse;
        }
        #endregion

        #region Check Key
        public static Boolean checkKey(Guid key)
        {
            return ApiKeyController.isKeyValid(key);
        }
        #endregion
        #region Validat Post Data
        public static Boolean validatePostData(UserPostData user)
        {
            if (user.user == null || user.user.Length == 0)
            {
                return false;
            }
            else if (user.title == null || user.title.Length == 0) {
                return false;
            }
            else if (user.downloadUrl == null || user.downloadUrl.Length == 0) {
                return false;
            }
            return true;
        }
        #endregion

        #region Process UserData
        public static List<ReturnData> processUserPostData(List<UserData> userData) {
            ReturnData returnData = null;
            List<ReturnData> returnList = new List<ReturnData>();
            if (userData != null && userData.Count > 0)
            {
                foreach (UserData user in userData)
                {
                    returnData = new ReturnData();
                    returnData.downloadUrl = user.downloadUrl;
                    returnData.title = user.title;
                    returnData.date = user.lastUpdated.ToString("MM-dd-yyyy");
                    returnData.ip = user.ip;
                    returnData.user = user.user;
                    returnList.Add(returnData);
                }
            }
            return returnList;
        }
        #endregion

    }
}