﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using cimetrix.Models;
using Newtonsoft.Json;
using cimetrix.Controllers;

namespace cimetrix
{
    public partial class AddUserData : System.Web.UI.Page
    {
        private WebResponseModel response;
        public string responseString;
        private Guid apiKey;
        protected void Page_Load(object sender, EventArgs e) 
        {
            if (this.Request.HttpMethod == "POST")
            {
                processData();
            }
        }

        private HttpResponse processData() {

            string jsonString = "";
            UserPostData userpostData = null;
            HttpContext.Current.Request.InputStream.Position = 0;
            using (StreamReader inputStream = new StreamReader(this.Request.InputStream))
            {
                jsonString = inputStream.ReadToEnd();
            }
            try
            {
                userpostData = JsonConvert.DeserializeObject<UserPostData>(jsonString);
            }
            catch (Exception e) {
                response = Utils.formatResponse(400, "Invaild Data Sent");
                responseString = JsonConvert.SerializeObject(response);
                Response.StatusCode = 400;
                Response.StatusDescription = "Invaild Data Sent";
                return Response;
            
            }
            if (userpostData.key != null && Utils.checkKey(userpostData.key))
            {
                if (!Utils.validatePostData(userpostData))
                {
                    response = Utils.formatResponse(400, "Invaild Data Sent");
                    responseString = JsonConvert.SerializeObject(response);
                    Response.StatusCode = 400;
                    Response.StatusDescription = "Invaild Data Sent";
                    return Response;
                }
                else
                {
                    UserData userData = new UserData();
                    userData.downloadUrl = userpostData.downloadUrl;
                    userData.title = userpostData.title;
                    userData.user = userpostData.user;
                    userData.ip = userpostData.ip;
                    UserController.recordData(userData);
                    response = Utils.formatResponse(200, "Success");
                    responseString = JsonConvert.SerializeObject(response);
                    Response.StatusCode = 200;
                    Response.StatusDescription = "Success";
                    return Response;
                }
            }
            else {
                response = Utils.formatResponse(404, "Page not Found");
                responseString = JsonConvert.SerializeObject(response);
                Response.StatusCode = 404;
                Response.StatusDescription = "Page not Found";
                return Response;
                
            }
           
        }
    }
}