﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using cimetrix.Models;
using cimetrix.Controllers;
using System.IO;
using Newtonsoft.Json;
using System.Globalization;

namespace cimetrix
{
    public partial class GetUserData : System.Web.UI.Page
    {
        #region Memebers
        private WebResponseModel response;
        public string responseString;
        private Guid apiKey;
        private String dateFormat = "yyyyMMdd";
        #endregion

        #region Page_Load
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.HttpMethod == "GET"  && Request.QueryString.Count == 2)
            {
                getUserDataByID();

            }
            else if (Request.HttpMethod == "GET"  && Request.QueryString.Count == 3)
            {
                getUserDataByDataRange();
            }

            else
            {
                return404Error();
            }
            
            
        }
        #endregion

        #region getUserDataByDataRange
        private void getUserDataByDataRange()
        {   
            UserPostData userpostData = new UserPostData();

            try
            {
                userpostData.key = new Guid(Request.Params.Get("key"));
                userpostData.startDate = DateTime.ParseExact(Request.Params.Get("startDate"), dateFormat,CultureInfo.InvariantCulture);
                userpostData.endDate = DateTime.ParseExact(Request.Params.Get("endDate"), dateFormat, CultureInfo.InstalledUICulture);     

            }
            catch (Exception e)
            {
                return404Error();
            }

            if (userpostData.key != null && Utils.checkKey(userpostData.key))
            {
                returnUserDatebyDateRange(userpostData);
            }
            else
            {
                return400Error("return400Error");
            }
        }
        #endregion

        #region returnUserDatebyDateRange
        private HttpResponse returnUserDatebyDateRange(UserPostData userPostData) {
            List<UserData> returnList = UserController.getUserDataByDateRanage(userPostData);
            response = Utils.formatResponse(200, "Success", Utils.processUserPostData(returnList));
            responseString = JsonConvert.SerializeObject(response);
            Response.StatusCode = 200;
            Response.StatusDescription = "Success";
            Response.Write(responseString.ToCharArray(), 0, responseString.Length);
            Response.ContentType = "application/json";
            return Response;
        
        }
        #endregion

        #region getUserDataByID

        private void getUserDataByID()
        {

            UserPostData userpostData = new UserPostData(); ;

            try
            {
                userpostData.key = new Guid(Request.Params.Get("key"));
                userpostData.user = Request.Params.Get("user");
            }
            catch (Exception e)
            {
                return404Error();
            }

            if (userpostData.key != null && Utils.checkKey(userpostData.key))
            {

                if (userpostData.user.Length > 0)
                {
                    returnUserDatabyUser(userpostData);
                }
                else {
                    return400Error("User Information Not Sent");
                }
               

            }
            else
            {
                return400Error("return400Error");
            }
        }
 
        #endregion

        #region returnUserDatabyUser

        private HttpResponse returnUserDatabyUser(UserPostData userpostData) {

            UserData userData = new UserData();
            userData.user = userpostData.user;
            List<UserData> returnList = UserController.getUserData(userData.user);
            response = Utils.formatResponse(200, "Success", Utils.processUserPostData(returnList));
            responseString = JsonConvert.SerializeObject(response);
            Response.StatusCode = 200;
            Response.StatusDescription = "Success";
            Response.Write(responseString.ToCharArray(), 0, responseString.Length);
            Response.ContentType = "application/json";
            return Response;
        }

        #endregion

        #region return400Error
        private HttpResponse return400Error(String message) {

            response = Utils.formatResponse(400, message);
            responseString = JsonConvert.SerializeObject(response);
            Response.StatusCode = 400;
            Response.StatusDescription = message;
            return Response;

        }
        #endregion

        #region return404Error
        private HttpResponse return404Error()
        {

            response = Utils.formatResponse(404, "Page not Found");
            responseString = JsonConvert.SerializeObject(response);
            Response.StatusCode = 404;
            Response.StatusDescription = "Page not Found";
            return Response;

        }
        #endregion
    }
}