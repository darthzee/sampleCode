﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using cimetrix.Dao;

namespace cimetrix.Controllers
{
    public class ApiKeyController
    {
        public static Boolean isKeyValid(Guid apiKey) {
            return ApiKeyDao.isKeyValid(apiKey);
        }
    }
}