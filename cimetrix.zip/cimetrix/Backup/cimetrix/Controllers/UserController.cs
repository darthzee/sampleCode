﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using cimetrix.Models;
using cimetrix.Dao;

namespace cimetrix.Controllers
{
    public class UserController
    {
        #region recordData
        public static void recordData(UserData user) {
            UserDao.recordData(user);            
        }
        #endregion

        #region getUserData
        public static List<UserData> getUserData(string user) {
            return UserDao.getUserData(user);
        }
        #endregion

        #region getUserDataByDateRanage
        public static List<UserData> getUserDataByDateRanage(UserPostData userPostData)
        {
            return UserDao.getUserDataByDateRanage(userPostData);
        }
        #endregion
    }
}