﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using cimetrix.Models;

namespace cimetrix.Dao
{
    public class UserDao
    {
        #region recordData
        public static void recordData(UserData user){

            UserDataDbDataContext db = new UserDataDbDataContext();
            var userQuery = from u in db.UserDatas where u.user == user.user && u.downloadUrl == user.downloadUrl select u;
            if (userQuery.FirstOrDefault() == null)
            {
                user.lastUpdated = DateTime.Now;
                user.createdOn = DateTime.Now;
                db.UserDatas.InsertOnSubmit(user);
            }
            else
            {
                foreach (UserData da in userQuery) {
                    da.lastUpdated = DateTime.Now;
                }
            }

            db.SubmitChanges();
        
        }
        #endregion

        #region getUserData
        public static List<UserData> getUserData(string userId)
        {
            UserDataDbDataContext db = new UserDataDbDataContext();
            var userQuery = from u in db.UserDatas where u.user == userId select u;
            if (userQuery.FirstOrDefault() != null)
            {
                List<UserData> userList = userQuery.ToList();
                if (userList != null){
                    return userList;
                }
                return null;
            }
            else
            {
                return null;
            }
        }
        #endregion

        #region getUserDataByDateRanage
        public static List<UserData> getUserDataByDateRanage(UserPostData userPostData)
        { 
            UserDataDbDataContext db = new UserDataDbDataContext();
            var userQuery = from u in db.UserDatas where u.lastUpdated >= userPostData.startDate && u.lastUpdated <= userPostData.endDate select u;
            if (userQuery.FirstOrDefault() != null)
            {
                List<UserData> userList = userQuery.ToList();
                if (userList != null){
                    return userList;
                }
                return null;
            }
            else
            {
                return null;
            }
        }
        #endregion
    }
}