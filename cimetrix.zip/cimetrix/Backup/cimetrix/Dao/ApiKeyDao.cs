﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using cimetrix.Models;

namespace cimetrix.Dao
{
    public class ApiKeyDao
    {

        public static Boolean isKeyValid(Guid key) {

            ApiKeyDBDataContext db = new ApiKeyDBDataContext();
            var keyQuery = from a in db.ApiKeys where a.api_key == key && a.disable_date == null select a;
            if (keyQuery.FirstOrDefault() == null)
            {
                return false;
            }
            else {
                return true;
            }
            
         
        }
     }
}